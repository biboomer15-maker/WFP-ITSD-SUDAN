import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

// ---------------------------------------------------------------
// WFP Sudan — IT Department app
// No login. Every service opens the WFP self-service portal.
// ---------------------------------------------------------------
const String kPortalUrl = 'https://selfservice.go.wfp.org/';
const String kEmail = 'Sudan.Itservicedesk@wfp.org';
const Color kWfpBlue = Color(0xFF1B4F8F);
const Color kWfpMidBlue = Color(0xFF2471B5);
const Color kWfpCyan = Color(0xFF009EDB);

Future<void> openLink(String url) async {
  final uri = Uri.parse(url);
  if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
    debugPrint('Could not launch $url');
  }
}

void main() => runApp(const WfpItApp());

class WfpItApp extends StatelessWidget {
  const WfpItApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Sudan Services Desk',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: Colors.white,
        colorScheme: ColorScheme.fromSeed(
          seedColor: kWfpBlue,
          primary: kWfpBlue,
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: kWfpBlue,
          foregroundColor: Colors.white,
          centerTitle: false,
        ),
      ),
      home: const HomeScreen(),
    );
  }
}

class Service {
  final String title;
  final String subtitle;
  final IconData icon;
  const Service(this.title, this.subtitle, this.icon);
}

const List<Service> kServices = [
  Service('IT helpdesk', 'Report an issue or ask for support', Icons.headset_mic_outlined),
  Service('Password reset', 'Reset your WFP account password', Icons.lock_reset_outlined),
  Service('Software request', 'Request installation or licenses', Icons.grid_view_outlined),
  Service('Equipment', 'Laptops, printers and peripherals', Icons.monitor_outlined),
  Service('Network & VPN', 'Connectivity and remote access', Icons.wifi_tethering_outlined),
  Service('Email & accounts', 'Mailbox and account services', Icons.alternate_email_outlined),
];

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 12,
        title: Row(
          children: [
            // Official WFP logo asset (drop wfp_logo.png into assets/)
            Image.asset(
              'assets/wfp_logo.png',
              height: 40,
              errorBuilder: (_, __, ___) => const Icon(Icons.public, color: Colors.white, size: 34),
            ),
            const SizedBox(width: 10),
            const Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Sudan Services Desk',
                      style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
                  Text('World Food Programme · Port Sudan Office',
                      style: TextStyle(fontSize: 11, color: Colors.white70)),
                ],
              ),
            ),
          ],
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Security banner
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                color: kWfpMidBlue.withOpacity(.08),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: kWfpMidBlue.withOpacity(.25)),
              ),
              child: const Row(
                children: [
                  Icon(Icons.verified_user_outlined, size: 18, color: kWfpBlue),
                  SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'No login required · Secure access · English',
                      style: TextStyle(fontSize: 12, color: kWfpBlue, fontWeight: FontWeight.w500),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),

            // About card
            _SectionTitle('About our IT team'),
            Card(
              elevation: 0,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14),
                side: BorderSide(color: Colors.blue.shade50),
              ),
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  children: [
                    Image.asset('assets/wfp_full_logo.png', height: 44,
                        errorBuilder: (_, __, ___) => const SizedBox.shrink()),
                    const SizedBox(height: 10),
                    const Text(
                  'The Information Technology Unit at WFP Sudan supports staff '
                  'across all field offices with reliable digital services — helpdesk '
                  'support, account management, connectivity and equipment — so '
                  'humanitarian operations never stop.',
                  style: TextStyle(fontSize: 13.5, height: 1.6, color: Color(0xFF3D4A63)),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 18),

            // Stats row
            const Row(
              children: [
                _StatChip(icon: Icons.support_agent, label: '24/7 helpdesk'),
                SizedBox(width: 8),
                _StatChip(icon: Icons.shield_outlined, label: 'Zero-login security'),
                SizedBox(width: 8),
                _StatChip(icon: Icons.language, label: 'All field offices'),
              ],
            ),
            const SizedBox(height: 18),

            // Services
            _SectionTitle('Our services — tap to open the portal'),
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
                childAspectRatio: 1.05,
              ),
              itemCount: kServices.length,
              itemBuilder: (_, i) => _ServiceCard(service: kServices[i]),
            ),
            const SizedBox(height: 20),

            // Contact card
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: kWfpBlue,
                borderRadius: BorderRadius.circular(16),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Contact the IT helpdesk',
                      style: TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 4),
                  const Text('No account needed. Send us a message and we will get back to you.',
                      style: TextStyle(color: Colors.white70, fontSize: 12)),
                  const SizedBox(height: 12),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      style: FilledButton.styleFrom(
                        backgroundColor: Colors.white,
                        foregroundColor: kWfpBlue,
                      ),
                      icon: const Icon(Icons.mail_outline, size: 18),
                      label: const Text('Email the IT team'),
                      onPressed: () => openLink(
                          'mailto:$kEmail?subject=IT%20Support%20Request'),
                    ),
                  ),
                  const SizedBox(height: 8),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      style: OutlinedButton.styleFrom(
                        foregroundColor: Colors.white,
                        side: const BorderSide(color: Colors.white54),
                      ),
                      icon: const Icon(Icons.open_in_new, size: 18),
                      label: const Text('Open WFP self-service portal'),
                      onPressed: () => openLink(kPortalUrl),
                    ),
                  ),
                  const SizedBox(height: 10),
                  const Text('$kEmail · selfservice.go.wfp.org',
                      style: TextStyle(color: Colors.white54, fontSize: 10.5)),
                ],
              ),
            ),
            const SizedBox(height: 14),
            const Center(
              child: Text('WFP Sudan IT Unit · Zero-login design for maximum security',
                  style: TextStyle(fontSize: 10, color: Color(0xFF93A1BE))),
            ),
          ],
        ),
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String text;
  const _SectionTitle(this.text);
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: Row(
          children: [
            Container(width: 3, height: 14, color: kWfpBlue),
            const SizedBox(width: 6),
            Text(text,
                style: const TextStyle(
                    fontSize: 14, fontWeight: FontWeight.w600, color: kWfpBlue)),
          ],
        ),
      );
}

class _StatChip extends StatelessWidget {
  final IconData icon;
  final String label;
  const _StatChip({required this.icon, required this.label});
  @override
  Widget build(BuildContext context) => Expanded(
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 6),
          decoration: BoxDecoration(
            color: const Color(0xFFEAF1FC),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Column(
            children: [
              Icon(icon, size: 20, color: kWfpBlue),
              const SizedBox(height: 4),
              Text(label,
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 10, color: kWfpBlue, fontWeight: FontWeight.w500)),
            ],
          ),
        ),
      );
}

class _ServiceCard extends StatelessWidget {
  final Service service;
  const _ServiceCard({required this.service});
  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(14),
        side: BorderSide(color: Colors.blue.shade50),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: () => openLink(kPortalUrl),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: const Color(0xFFEAF1FC),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(service.icon, color: kWfpBlue, size: 24),
              ),
              const SizedBox(height: 8),
              Text(service.title,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                      fontSize: 12.5, fontWeight: FontWeight.w600, color: kWfpBlue)),
              const SizedBox(height: 3),
              Text(service.subtitle,
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 10, color: Color(0xFF7A869E), height: 1.3)),
            ],
          ),
        ),
      ),
    );
  }
}
