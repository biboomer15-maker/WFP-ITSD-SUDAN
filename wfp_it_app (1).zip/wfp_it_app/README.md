# Sudan Services Desk — WFP Sudan IT app

Flutter app for the WFP Sudan (Port Sudan office) IT Unit.
No login — every service opens the WFP self-service portal.

## Build the APK WITHOUT a laptop (phone only)

1. Create a free GitHub account (github.com) — works in the phone browser.
2. Create a new repository named `sudan-services-desk`.
3. Upload ALL the files of this project to the repository (Add file → Upload files,
   or use the GitHub app). Keep the folder structure: lib/, assets/, android/,
   pubspec.yaml, .github/workflows/.
4. The workflow `.github/workflows/build_apk.yml` runs automatically on upload.
5. Open the repository → Actions tab → "Build Sudan Services Desk APK" →
   wait ~10 minutes → open the finished run → "Artifacts" →
   download **SudanServicesDesk-APK**.
6. Open the downloaded APK on your phone → Install (allow "install from unknown
   sources" if asked).

Replace `assets/wfp_logo.png` with the official WFP logo before building
(brand kit: https://cdn.wfp.org/guides/ui/).

## Links
- Portal: https://selfservice.go.wfp.org/
- Email: Sudan.Itservicedesk@wfp.org
